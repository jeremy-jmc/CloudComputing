from airflow import DAG
from airflow.decorators import task
from datetime import datetime
import pandas as pd

# Definir el DAG
dag = DAG(
    'etl_data_ficticia',
    description='ETL con data ficticia',
    schedule_interval='@once',
    start_date=datetime(2024, 1, 1),
    catchup=False,
)

# Tarea para extraer datos ficticios
@task(dag=dag)
def extract_data():
    # Crear un DataFrame con datos ficticios
    data = {
        'NAME': ['Alice', 'Bob', 'Charlie', 'David'],
        'AGE': [25, 30, 35, 40],
        'CITY': ['New York', 'Los Angeles', 'Chicago', 'Houston']
    }
    df = pd.DataFrame(data)
    df.to_csv('/tmp/fictitious_data.csv', index=False)
    print(df)
    print("Tarea 1: OK")

# Tarea para transformar los datos
@task(dag=dag)
def transform_data():
    df = pd.read_csv('/tmp/fictitious_data.csv')
    # Realiza tus transformaciones aquí
    # Ejemplo: Convertir todos los nombres de columnas a minúsculas
    df.columns = [col.lower() for col in df.columns]
    df.to_csv('/tmp/transformed_data.csv', index=False)
    print("Tarea 2: OK")

# Tarea para cargar los datos y mostrarlos en pantalla
@task(dag=dag)
def load_and_display_data():
    df = pd.read_csv('/tmp/transformed_data.csv')
    print(df)
    print("Tarea 3: OK")

# Establecer las dependencias entre tareas
extract_task = extract_data()
transform_task = transform_data()
load_task = load_and_display_data()

extract_task >> transform_task >> load_task
