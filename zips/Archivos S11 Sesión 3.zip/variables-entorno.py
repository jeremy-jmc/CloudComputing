import os
alumno = os.environ["NOMBRE_ALUMNO"]
empresa = os.environ["NOMBRE_EMPRESA"]
print(alumno)
print(empresa)