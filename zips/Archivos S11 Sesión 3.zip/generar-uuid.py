import uuid
uuidv1 = str(uuid.uuid1())
uuidv4 = str(uuid.uuid4())
print("UUID en V1: ", uuidv1)
print("UUID en V4: ", uuidv4)