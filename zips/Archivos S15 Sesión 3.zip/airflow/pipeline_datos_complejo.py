from airflow import DAG
from airflow.decorators import task
from datetime import datetime, timedelta

# Definir los argumentos por defecto del DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 11, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Definir el DAG
dag = DAG(
    'pipeline_datos_complejo',
    default_args=default_args,
    description='Un DAG simple con 5 funciones que se ejecuta cada día',
    schedule_interval='@daily',
    tags=['complejo', 'diario'],
)

@task(dag=dag)
def tarea1():
    print("Soy la Tarea 1")

@task(dag=dag)
def tarea2():
    print("Soy la Tarea 2")

@task(dag=dag)
def tarea3():
    print("Soy la Tarea 3")

@task(dag=dag)
def tarea4():
    print("Soy la Tarea 4")

@task(dag=dag)
def tarea5():
    print("Soy la Tarea 5")

# Establecer las dependencias entre tareas
t1 = tarea1()
t2 = tarea2()
t3 = tarea3()
t4 = tarea4()
t5 = tarea5()

t1 >> t2 >> t5
t1 >> t3 >> t5
t1 >> t4 >> t5